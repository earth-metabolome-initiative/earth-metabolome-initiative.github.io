---
title: Gaetan Glauser
firstname: Gaetan
lastname: Glauser
institution: 
email: gaetan.glauser@unine.ch
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/gaetan-glauser.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
