---
title: Rodrigo Camara-leret
firstname: Rodrigo
lastname: Camara-leret
institution: 
email: rodrigo.camaraleret@ieu.uzh.ch
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/rodrigo-camara-leret.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
