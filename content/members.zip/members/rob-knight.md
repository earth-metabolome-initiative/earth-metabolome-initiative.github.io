---
title: Rob Knight
firstname: Rob
lastname: Knight
institution: 
email: rknight@ucsd.edu
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/rob-knight.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
