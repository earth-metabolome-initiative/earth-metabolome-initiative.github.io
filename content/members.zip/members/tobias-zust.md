---
title: Tobias Zust
firstname: Tobias
lastname: Zust
institution: 
email: tobias.zuest@uzh.ch
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/tobias-zust.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
