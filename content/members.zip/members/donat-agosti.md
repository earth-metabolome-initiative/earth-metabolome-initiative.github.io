---
title: Donat Agosti
firstname: Donat
lastname: Agosti
institution: Naturhistorisches Museum, Berne, Switzerland
email: agosti@plazi.org
orcid: https://orcid.org/0000-0001-9286-1200
wikidata: https://www.wikidata.org/wiki/Q20650434
scholia: https://scholia.toolforge.org/author/Q20650434
thumbnail:
  url: /img/members/donat-agosti.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 52.5127
popupLong: 13.3992
type: members
---

## Who am I ?

Donat is Swiss myrmecologist and open access activist.

## Collaboration statement

{{< map >}}
