---
title: Peter Murray-rust
firstname: Peter
lastname: Murray-rust
institution: 
email: pm286@cam.ac.uk
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/peter-murray-rust.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
