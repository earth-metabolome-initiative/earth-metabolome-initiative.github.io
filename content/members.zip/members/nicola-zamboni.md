---
title: Nicola Zamboni
firstname: Nicola
lastname: Zamboni
institution: 
email: zamboni@imsb.biol.ethz.ch
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/nicola-zamboni.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
