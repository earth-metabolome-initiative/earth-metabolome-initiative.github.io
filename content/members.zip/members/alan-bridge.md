---
title: Alan Bridge
firstname: Alan
lastname: Bridge
institution: SIB Swiss Institute of Bioinformatics
email: Alan.Bridge@sib.swiss
orcid: https://orcid.org/0000-0003-2148-9135
wikidata: 
scholia: 
thumbnail:
  url: /img/members/alan-bridge.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 46.523110
popupLong: 6.583900
type: members
---

{{< persona_links >}}

{{< map >}}
