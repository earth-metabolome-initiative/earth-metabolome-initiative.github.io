---
title: Christophe Dessimoz
firstname: Christophe
lastname: Dessimoz
institution: 
email: christophe.dessimoz@sib.swiss
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/christophe-dessimoz.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
