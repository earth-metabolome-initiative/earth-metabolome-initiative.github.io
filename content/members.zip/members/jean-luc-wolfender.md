---
title: Jean-luc Wolfender
firstname: Jean-luc
lastname: Wolfender
institution: 
email: jean-luc.wolfender@unige.ch
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/jean-luc-wolfender.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
