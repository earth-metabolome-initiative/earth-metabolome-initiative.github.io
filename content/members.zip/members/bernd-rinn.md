---
title: Bernd Rinn
firstname: Bernd
lastname: Rinn
institution: 
email: test@example.org
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/bernd-rinn.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
