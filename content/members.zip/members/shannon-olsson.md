---
title: Shannon Olsson
firstname: Shannon
lastname: Olsson
institution: 
email: shannon@nice.ncbs.res.in
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/shannon-olsson.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
