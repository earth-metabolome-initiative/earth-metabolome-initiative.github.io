---
title: Barry Okeefe
firstname: Barry
lastname: Okeefe
institution: 
email: okeefeba@mail.nih.gov
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/barry-okeefe.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
