---
title: Daniel Mietchen
firstname: Daniel
lastname: Mietchen
institution: 
email: daniel.mietchen@igb-berlin.de
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/daniel-mietchen.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
