---
title: Jean-marc Nuzillard
firstname: Jean-marc
lastname: Nuzillard
institution: 
email: jm.nuzillard@univ-reims.fr
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/jean-marc-nuzillard.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
