---
title: Tarcisio Mendes
firstname: Tarcisio
lastname: Mendes
institution: 
email: tarcisio.mendes@sib.swiss
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/tarcisio-mendes.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
