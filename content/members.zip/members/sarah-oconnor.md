---
title: Sarah Oconnor
firstname: Sarah
lastname: Oconnor
institution: 
email: oconnor@ice.mpg.de
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/sarah-oconnor.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
