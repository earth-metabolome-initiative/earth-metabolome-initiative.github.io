---
title: Tomas Pluskal
firstname: Tomas
lastname: Pluskal
institution: 
email: tomas.pluskal@uochb.cas.cz
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/tomas-pluskal.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
