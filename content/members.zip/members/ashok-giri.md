---
title: Ashok Giri
firstname: Ashok
lastname: Giri
institution: 
email: ap.giri@ncl.res.in
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/ashok-giri.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
