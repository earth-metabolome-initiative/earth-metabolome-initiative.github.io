---
title: Amy Trowbridge
firstname: Amy
lastname: Trowbridge
institution: University of Wisconsin–Madison, Department of Forest & Wildlife Ecology
email: amtrowbridge@wisc.edu
orcid: https://orcid.org/0000-0001-8993-2530
wikidata:
scholia:
thumbnail:
  url: /img/members/amy-trowbridge.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 43.071841
popupLong: -89.400345
type: members
---

{{< persona_links >}}

{{< map >}}