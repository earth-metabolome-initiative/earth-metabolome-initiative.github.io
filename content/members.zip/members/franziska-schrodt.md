---
title: Franziska Schrodt
firstname: Franziska
lastname: Schrodt
institution: 
email: Franziska.Schrodt1@nottingham.ac.uk
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/franziska-schrodt.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
