---
title: Daniel Petras
firstname: Daniel
lastname: Petras
institution: 
email: functionalmetabolomics@gmail.com
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/daniel-petras.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
