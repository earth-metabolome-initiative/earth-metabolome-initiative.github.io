---
title: Bruno David
firstname: Bruno
lastname: David
institution: 
email: brunoxdavid@gmail.com
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/bruno-david.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
