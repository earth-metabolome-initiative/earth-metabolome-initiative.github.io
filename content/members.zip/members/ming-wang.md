---
title: Ming Wang
firstname: Ming
lastname: Wang
institution: 
email: mingxun.wang@cs.ucr.edu
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/ming-wang.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
