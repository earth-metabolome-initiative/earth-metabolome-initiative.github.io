---
title: Jorn Piel
firstname: Jorn
lastname: Piel
institution: 
email: jpiel@micro.biol.ethz.ch
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/jorn-piel.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
