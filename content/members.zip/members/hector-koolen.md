---
title: Hector Koolen
firstname: Hector
lastname: Koolen
institution: 
email: Hectorkoolen@gmail.com
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/hector-koolen.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
