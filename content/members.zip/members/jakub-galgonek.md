---
title: Jakub Galgonek
firstname: Jakub
lastname: Galgonek
institution: 
email: jakub.galgonek@uochb.cas.cz
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/jakub-galgonek.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
