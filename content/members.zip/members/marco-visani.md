---
title: Marco Visani
firstname: Marco
lastname: Visani
institution: 

orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/marco-visani.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
