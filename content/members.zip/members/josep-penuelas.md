---
title: Josep Penuelas
firstname: Josep
lastname: Penuelas
institution: 
email: josep.penuelas@uab.cat
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/josep-penuelas.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
