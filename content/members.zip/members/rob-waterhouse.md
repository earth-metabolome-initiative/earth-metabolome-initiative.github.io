---
title: Rob Waterhouse
firstname: Rob
lastname: Waterhouse
institution: 
email: robert.waterhouse@unil.ch
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/rob-waterhouse.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
