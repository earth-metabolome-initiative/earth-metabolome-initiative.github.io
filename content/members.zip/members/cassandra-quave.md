---
title: Cassandra Quave
firstname: Cassandra
lastname: Quave
institution: 
email: cassandra.leah.quave@emory.edu
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/cassandra-quave.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
