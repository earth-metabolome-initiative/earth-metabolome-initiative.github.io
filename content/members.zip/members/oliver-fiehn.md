---
title: Oliver Fiehn
firstname: Oliver
lastname: Fiehn
institution: 
email: test@example.org
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/oliver-fiehn.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
