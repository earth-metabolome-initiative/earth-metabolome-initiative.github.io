---
title: Lora Richards
firstname: Lora
lastname: Richards
institution: 
email: lorar@unr.edu
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/lora-richards.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
