---
title: Marco Pagni
firstname: Marco
lastname: Pagni
institution: 
email: Marco.Pagni@sib.swiss
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/marco-pagni.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
