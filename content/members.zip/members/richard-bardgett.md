---
title: Richard Bardgett
firstname: Richard
lastname: Bardgett
institution: 
email: richard.bardgett@manchester.ac.uk
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/richard-bardgett.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
