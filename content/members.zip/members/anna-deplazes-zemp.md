---
title: Anna Deplazes-zemp
firstname: Anna
lastname: Deplazes-zemp
institution: 
email: deplazes@ethik.uzh.ch
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/anna-deplazes-zemp.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
