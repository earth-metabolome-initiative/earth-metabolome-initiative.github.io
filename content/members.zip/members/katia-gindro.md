---
title: Katia Gindro
firstname: Katia
lastname: Gindro
institution: 
email: katia.gindro@agroscope.admin.ch
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/katia-gindro.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
