---
title: Maggie Reddy
firstname: Maggie
lastname: Reddy
institution: 
email: maggiereddy0402@gmail.com
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/maggie-reddy.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
