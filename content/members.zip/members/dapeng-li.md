---
title: Dapeng Li
firstname: Dapeng
lastname: Li
institution: 
email: dpli@cemps.ac.cn
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/dapeng-li.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
