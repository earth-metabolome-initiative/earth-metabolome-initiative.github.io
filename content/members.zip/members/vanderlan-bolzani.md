---
title: Vanderlan Bolzani
firstname: Vanderlan
lastname: Bolzani
institution: 
email: bolzaniv@iq.unesp.br
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/vanderlan-bolzani.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
