---
title: Heloise Coen
firstname: Heloise
lastname: Coen
institution: 

orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/heloise-coen.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
