---
title: Justin Vanderhooft
firstname: Justin
lastname: Vanderhooft
institution: 
email: justin.vanderhooft@wur.nl
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/justin-vanderhooft.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
