---
title: Bernhard Schmid
firstname: Bernhard
lastname: Schmid
institution: 
email: bernhard.schmid@ieu.uzh.ch
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/bernhard-schmid.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
