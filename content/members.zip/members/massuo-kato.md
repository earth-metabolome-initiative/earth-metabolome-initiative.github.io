---
title: Massuo Kato
firstname: Massuo
lastname: Kato
institution: 
email: majokato@iq.usp.br
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/massuo-kato.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
