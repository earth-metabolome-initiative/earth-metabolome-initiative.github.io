---
title: Florian Huber
firstname: Florian
lastname: Huber
institution: 
email: florian.huber@hs-duesseldorf.de
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/florian-huber.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
