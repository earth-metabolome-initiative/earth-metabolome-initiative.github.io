---
title: Ana‑Claudia Sima
firstname: Ana‑claudia
lastname: Sima
institution: SIB Swiss Institute of Bioinformatics, Lausanne (Knowledge Representation Unit)
email: test@example.org
orcid: https://orcid.org/0000-0003-3213-4495
wikidata:
scholia:
thumbnail:
  url: /img/members/ana-claudia-sima.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 46.523100
popupLong: 6.583850
type: members
---

{{< persona_links >}}

{{< map >}}