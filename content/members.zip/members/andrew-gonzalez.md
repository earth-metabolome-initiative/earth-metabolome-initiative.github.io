---
title: Andrew Gonzalez
firstname: Andrew
lastname: Gonzalez
institution: 
email: andrew.gonzalez@mcgill.ca
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/andrew-gonzalez.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
