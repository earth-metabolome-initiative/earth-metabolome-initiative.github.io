---
title: Meredith Schuman
firstname: Meredith
lastname: Schuman
institution: 

orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/meredith-schuman.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
