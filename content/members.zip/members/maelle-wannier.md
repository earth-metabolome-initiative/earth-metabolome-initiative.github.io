---
title: Maelle Wannier
firstname: Maelle
lastname: Wannier
institution: 

orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/maelle-wannier.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
