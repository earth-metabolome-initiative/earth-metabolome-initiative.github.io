---
title: Jiri Vondrasek
firstname: Jiri
lastname: Vondrasek
institution: 
email: jiri.vondrasek@uochb.cas.cz
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/jiri-vondrasek.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
