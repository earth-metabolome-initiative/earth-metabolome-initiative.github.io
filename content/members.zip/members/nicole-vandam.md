---
title: Nicole Vandam
firstname: Nicole
lastname: Vandam
institution: 
email: nicole.vandam@idiv.de
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/nicole-vandam.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
