---
title: Laurent Bigler
firstname: Laurent
lastname: Bigler
institution: 
email: laurent.bigler@chem.uzh.ch
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/laurent-bigler.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
