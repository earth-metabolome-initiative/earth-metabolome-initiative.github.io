---
title: Egon Willighagen
firstname: Egon
lastname: Willighagen
institution: 
email: egon.willighagen@maastrichtuniversity.nl
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/egon-willighagen.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
