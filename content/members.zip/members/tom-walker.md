---
title: Tom Walker
firstname: Tom
lastname: Walker
institution: 
email: test@example.org
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/tom-walker.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
