---
title: Emmanuel Gaquerel
firstname: Emmanuel
lastname: Gaquerel
institution: 
email: emmanuel.gaquerel@ibmp-cnrs.unistra.fr
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/emmanuel-gaquerel.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
