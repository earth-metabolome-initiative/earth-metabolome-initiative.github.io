---
title: Caroline Muller
firstname: Caroline
lastname: Muller
institution: 
email: caroline.mueller@uni-bielefeld.de
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/caroline-muller.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
