---
title: Daniele Silvestro
firstname: Daniele
lastname: Silvestro
institution: 
email: daniele.silvestro@unifr.ch
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/daniele-silvestro.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
