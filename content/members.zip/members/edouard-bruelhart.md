---
title: Edouard Bruelhart
firstname: Edouard
lastname: Bruelhart
institution: 
email: test@example.org
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/edouard-bruelhart.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
