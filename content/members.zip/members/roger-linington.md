---
title: Roger Linington
firstname: Roger
lastname: Linington
institution: 
email: rliningt@sfu.ca
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/roger-linington.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
