---
title: Neil Kelleher
firstname: Neil
lastname: Kelleher
institution: 
email: n-kelleher@northwestern.edu
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/neil-kelleher.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
