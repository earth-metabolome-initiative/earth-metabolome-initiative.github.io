---
title: Henry Luetcke
firstname: Henry
lastname: Luetcke
institution: 
email: test@example.org
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/henry-luetcke.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
