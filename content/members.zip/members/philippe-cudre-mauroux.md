---
title: Philippe Cudre-mauroux
firstname: Philippe
lastname: Cudre-mauroux
institution: 
email: phil@exascale.info
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/philippe-cudre-mauroux.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
