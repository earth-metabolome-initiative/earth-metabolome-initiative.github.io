---
title: Cornelia Krug
firstname: Cornelia
lastname: Krug
institution: 
email: cornelia.krug@uzh.ch
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/cornelia-krug.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
