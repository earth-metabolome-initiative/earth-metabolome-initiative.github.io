---
title: Olivier Thomas
firstname: Olivier
lastname: Thomas
institution: 
email: olivier.thomas@nuigalway.ie
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/olivier-thomas.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
