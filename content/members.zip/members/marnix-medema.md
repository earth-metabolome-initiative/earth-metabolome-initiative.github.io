---
title: Marnix Medema
firstname: Marnix
lastname: Medema
institution: 
email: marnix.medema@wur.nl
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/marnix-medema.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
