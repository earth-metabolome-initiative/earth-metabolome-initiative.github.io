---
title: Mehdi Beniddir
firstname: Mehdi
lastname: Beniddir
institution: 
email: mehdi.beniddir@universite-paris-saclay.fr
orcid: https://orcid.org/0000-0003-2153-4290
wikidata: https://www.wikidata.org/wiki/Q57858606
scholia: https://scholia.toolforge.org/author/Q57858606
thumbnail:
  url: /img/members/mehdi-beniddir.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 48.7326000
popupLong: 2.1692300
type: members
---

{{< persona_links >}}

----

{{< map >}}
