---
title: Marc Litaudon
firstname: Marc
lastname: Litaudon
institution: 
email: marc.litaudon@cnrs.fr
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/marc-litaudon.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
