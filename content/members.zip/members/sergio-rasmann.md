---
title: Sergio Rasmann
firstname: Sergio
lastname: Rasmann
institution: 
email: sergio.rasmann@unine.ch
orcid: 
wikidata: 
scholia: 
thumbnail:
  url: /img/members/sergio-rasmann.jpeg
modules: ["leaflet"]
popup: "Here I am"
popupLat: 
popupLong: 
type: members
---

{{< persona_links >}}

{{< map >}}
